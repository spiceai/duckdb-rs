#include "src/core_functions/scalar/date/age.cpp"

#include "src/core_functions/scalar/date/current.cpp"

#include "src/core_functions/scalar/date/epoch.cpp"

#include "src/core_functions/scalar/date/date_diff.cpp"

#include "src/core_functions/scalar/date/date_part.cpp"

#include "src/core_functions/scalar/date/date_sub.cpp"

#include "src/core_functions/scalar/date/date_trunc.cpp"

#include "src/core_functions/scalar/date/make_date.cpp"

#include "src/core_functions/scalar/date/strftime.cpp"

#include "src/core_functions/scalar/date/time_bucket.cpp"

#include "src/core_functions/scalar/date/to_interval.cpp"

