#include "extension/core_functions/scalar/enum/enum_functions.cpp"

