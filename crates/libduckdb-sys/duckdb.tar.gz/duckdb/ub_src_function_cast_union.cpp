#include "src/function/cast/union/from_struct.cpp"

