#include "src/core_functions/scalar/union/union_extract.cpp"

#include "src/core_functions/scalar/union/union_tag.cpp"

#include "src/core_functions/scalar/union/union_value.cpp"

