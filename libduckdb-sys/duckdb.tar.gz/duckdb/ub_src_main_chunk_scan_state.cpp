#include "src/main/chunk_scan_state/query_result.cpp"

