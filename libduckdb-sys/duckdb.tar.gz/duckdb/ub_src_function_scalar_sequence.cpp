#include "src/function/scalar/sequence/nextval.cpp"

